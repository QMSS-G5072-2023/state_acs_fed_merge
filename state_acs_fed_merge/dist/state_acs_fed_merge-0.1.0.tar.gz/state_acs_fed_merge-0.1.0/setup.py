# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['state_acs_fed_merge']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.26.2,<2.0.0',
 'pandas==1.5.2',
 'prettytable>=3.9.0,<4.0.0',
 'python-decouple>=3.8,<4.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'requests>=2.31.0,<3.0.0',
 'ruamel.yaml==0.17.4']

setup_kwargs = {
    'name': 'state-acs-fed-merge',
    'version': '0.1.0',
    'description': 'Package ffor merging annual state-level American Community Survey data with state-level data from the federal reserve.',
    'long_description': '# state_acs_fed_merge\n\nPackage ffor merging annual state-level American Community Survey data with state-level data from the federal reserve.\n\n## Installation\n\n```bash\n$ pip install state_acs_fed_merge\n```\n\n## Usage\n\n-   Pull annual state-level data from American Community Survey and merge with state-level minumum wage, \n    unemployment, and gdp data for those states and years.\n\n    This function determines the average of any requested variable available in the American\n    Community Survey data for a specific state and year using data queried from IPUMS-ACS :\n    https://usa.ipums.org/usa/\n\n    It then draws data from the Federal Reserve on annual state-level data that is readily available, \n    including  tate-level minumum wage, unemployment, and gdp data for those states and years.  \n    Federal reserve data is pulled from https://fred.stlouisfed.org/. \n    \n    The input are: \n    state_list : str\n        list of state fip codes for states that you would like to pull data on \n        see state fip codes here:https://transition.fcc.gov/oet/info/maps/census/fips/fips.txt\n        \n    years : int\n        single year or list of years for which you would like data \n\n    var_list : str\n        list of variables from the American Community Survey for which you would like state-leve avarages. \n        see variable list here: https://usa.ipums.org/usa-action/variables/search \n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`state_acs_fed_merge` was created by Sophie Collyer. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`state_acs_fed_merge` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Sophie Collyer',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
