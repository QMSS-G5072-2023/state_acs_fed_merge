# read version from installed package
from importlib.metadata import version
__version__ = version("state_acs_fed_merge")